from django.shortcuts import get_object_or_404, render, render_to_response
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.views import generic
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from kca.models import Choice, Poll, Forum, Notice, Result, Itnews,Dataroom,FAQ,Recurit

from django.core.urlresolvers import reverse
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import send_mail

def main(request):
    """Main listing.""" 
    forums = Forum.objects.all() 
    return render_to_response("kca/07notice/notice.html", dict(forums=forums, user=request.user))


class IndexView(generic.ListView):
    template_name = 'kca/index.html'
    context_object_name = 'latest_poll_list'

    notices = Notice.objects.order_by('-id')
    
    def get_queryset(self):
        """Return the last five published kca."""
        return Poll.objects.order_by('-pub_date')[:5]

def IndexDataView(request):
    notices = Notice.objects.order_by('-id')
    paginator = Paginator(notices, 5) 
    
    results = Result.objects.order_by('-id')
    resultpaginator = Paginator(results, 5)
    page = request.GET.get('page')
    try:
        pagenotices = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        pagenotices = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        pagenotices = paginator.page(paginator.num_pages)



    return render(request, 'kca/index.html', dict(notices=pagenotices, results=resultpaginator.page(1)))

class DetailView(generic.DetailView):
    model = Poll
#     template_name = 'kca/detail.html'
    template_name = 'kca/sub_aduit_01_01.html'

class DetailView2(generic.DetailView):
    model = Poll
#     template_name = 'kca/detail.html'
    template_name = 'kca/sidemenu.html'


class ResultsView(generic.DetailView):
    model = Poll
    template_name = 'kca/results.html'

def SubAuditPopCalView(request):
    return render(request, 'kca/02audit/pop_audit_cal.html')

def SubCompanay0101View(request):
    return render(request, 'kca/01company/sub_company_01_01.html')
     
def SitemapView(request):
    return render(request, 'kca/sitemap.html')
def SubCompanay0201View(request):
    return render(request, 'kca/01company/sub_company_02_01.html')
def SubCompanay0301View(request):
    return render(request, 'kca/01company/sub_company_03_01.html')
def SubCompanay0401View(request):
    return render(request, 'kca/01company/sub_company_04_01.html')
def SubCompanay0501View(request):
    return render(request, 'kca/01company/sub_company_05_01.html')
def SubCompanay0601View(request):
    return render(request, 'kca/01company/sub_company_06_01.html')
def SubCompanay0701View(request):
    return render(request, 'kca/01company/sub_company_07_01.html')
def SubCompanay0801View(request):
    return render(request, 'kca/01company/sub_company_08_01.html')    
def SubAudit0101View(request):
    return render(request, 'kca/02audit/sub_audit_01_01.html')
def SubAudit0102View(request):
    return render(request, 'kca/02audit/sub_audit_01_02.html')
def SubAudit0103View(request):
    return render(request, 'kca/02audit/sub_audit_01_03.html')
def SubAudit0104View(request):
    return render(request, 'kca/02audit/sub_audit_01_04.html')
def SubAudit0105View(request):
    return render(request, 'kca/02audit/sub_audit_01_05.html')
def SubAudit0106View(request):
    return render(request, 'kca/02audit/sub_audit_01_06.html')
def SubAudit0201View(request):
    return render(request, 'kca/02audit/sub_audit_02_01.html')
def SubAudit0202View(request):
    return render(request, 'kca/02audit/sub_audit_02_02.html')
def SubAudit0203View(request):
    return render(request, 'kca/02audit/sub_audit_02_03.html')
def SubAudit0301View(request):
    return render(request, 'kca/02audit/sub_audit_03_01.html')
def SubAudit0302View(request):
    return render(request, 'kca/02audit/sub_audit_03_02.html')
def SubAudit0303View(request):
    return render(request, 'kca/02audit/sub_audit_03_03.html')
def SubAudit0304View(request):
    return render(request, 'kca/02audit/sub_audit_03_04.html')
def SubAudit0305View(request):
    return render(request, 'kca/02audit/sub_audit_03_05.html')
def SubAudit0401View(request):
    return render(request, 'kca/02audit/sub_audit_04_01.html')
def SubAudit0402View(request):
    return render(request, 'kca/02audit/sub_audit_04_02.html')
def SubAudit0403View(request):
    return render(request, 'kca/02audit/sub_audit_04_03.html')
def SubAudit0501View(request):
    return render(request, 'kca/02audit/sub_audit_05_01.html')
def SubAudit0502View(request):
    return render(request, 'kca/02audit/sub_audit_05_02.html')
def SubConsulting0101View(request):
    return render(request, 'kca/03consulting/sub_consulting_01_01.html')
def SubConsulting0102View(request):
    return render(request, 'kca/03consulting/sub_consulting_01_02.html')
def SubConsulting0201View(request):
    return render(request, 'kca/03consulting/sub_consulting_02_01.html')
def SubConsulting0202View(request):
    return render(request, 'kca/03consulting/sub_consulting_02_02.html')
def SubConsulting0301View(request):
    return render(request, 'kca/03consulting/sub_consulting_03_01.html')
def SubConsulting0302View(request):
    return render(request, 'kca/03consulting/sub_consulting_03_02.html')
def SubSecurity0101View(request):
    return render(request, 'kca/04security/sub_security_01_01.html')
def SubSecurity0201View(request):
    return render(request, 'kca/04security/sub_security_02_01.html')
def SubSecurity0301View(request):
    return render(request, 'kca/04security/sub_security_03_01.html')
def SubSecurity0302View(request):
    return render(request, 'kca/04security/sub_security_03_02.html')
def SubSecurity0303View(request):
    return render(request, 'kca/04security/sub_security_03_03.html')
def SubSecurity0304View(request):
    return render(request, 'kca/04security/sub_security_03_04.html')
def SubSecurity0401View(request):
    return render(request, 'kca/04security/sub_security_04_01.html')
def SubSecurity0402View(request):
    return render(request, 'kca/04security/sub_security_04_02.html')
def SubSecurity0403View(request):
    return render(request, 'kca/04security/sub_security_04_03.html')
def SubSecurity0404View(request):
    return render(request, 'kca/04security/sub_security_04_04.html')
def SubPmo0101View(request):
    return render(request, 'kca/05pmo/sub_pmo_01_01.html')
def SubPmo0201View(request):
    return render(request, 'kca/05pmo/sub_pmo_02_01.html')
def SubEdu0101View(request):
    return render(request, 'kca/06education/sub_education_01_01.html')
def SubEdu0201View(request):
    return render(request, 'kca/06education/sub_education_02_01.html')
def SubEdu0301View(request):
    return render(request, 'kca/06education/sub_education_03_01.html')
def SubEdu0401View(request):
    return render(request, 'kca/06education/sub_education_04_01.html')
@csrf_exempt
def SubNotice0101View(request):
#     notices = Notice.objects.all().order_by('-id')
    searchStr = request.POST.get('searchStr',"")
    
    notices = Notice.objects.filter(content__contains=searchStr).order_by('-id')
    paginator = Paginator(notices, 10) 
    
    page = request.GET.get('page')
    try:
        pagenotices = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        pagenotices = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        pagenotices = paginator.page(paginator.num_pages)

    return render(request, 'kca/07notice/sub_notice_01_01.html', dict(notices=pagenotices, user=request.user))
def SubNotice0102View(request, pk):
    notices = Notice.objects.filter(id = pk)
    return render(request, "kca/07notice/sub_notice_01_02.html", dict(notices=notices, user=request.user))
def SubNotice0201View(request):
#     notices = Notice.objects.all().order_by('-id')
    searchStr = request.POST.get('searchStr',"")
    
    notices = Result.objects.filter(content__contains=searchStr).order_by('-id')
    paginator = Paginator(notices, 10) 
    
    page = request.GET.get('page')
    try:
        pagenotices = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        pagenotices = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        pagenotices = paginator.page(paginator.num_pages)

    return render(request, 'kca/07notice/sub_notice_02_01.html', dict(notices=pagenotices, user=request.user))
def SubNotice0202View(request, pk):
    notices = Result.objects.filter(id = pk)
    return render(request, "kca/07notice/sub_notice_02_02.html", dict(notices=notices, user=request.user))

def SubNotice0301View(request):
#     notices = Notice.objects.all().order_by('-id')
    searchStr = request.POST.get('searchStr',"")
    
    notices = Itnews.objects.filter(content__contains=searchStr).order_by('-id')
    paginator = Paginator(notices, 10) 
    
    page = request.GET.get('page')
    try:
        pagenotices = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        pagenotices = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        pagenotices = paginator.page(paginator.num_pages)

    return render(request, 'kca/07notice/sub_notice_03_01.html', dict(notices=pagenotices, user=request.user))
def SubNotice0302View(request, pk):
    notices = Itnews.objects.filter(id = pk)
    return render(request, "kca/07notice/sub_notice_03_02.html", dict(notices=notices, user=request.user))

def SubNotice0401View(request):
#     notices = Notice.objects.all().order_by('-id')
    searchStr = request.POST.get('searchStr',"")
    
    notices = Dataroom.objects.filter(content__contains=searchStr).order_by('-id')
    paginator = Paginator(notices, 10) 
    
    page = request.GET.get('page')
    try:
        pagenotices = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        pagenotices = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        pagenotices = paginator.page(paginator.num_pages)

    return render(request, 'kca/07notice/sub_notice_04_01.html', dict(notices=pagenotices, user=request.user))
def SubNotice0402View(request, pk):
    notices = Dataroom.objects.filter(id = pk)
    return render(request, "kca/07notice/sub_notice_04_02.html", dict(notices=notices, user=request.user))

def SubNotice0501View(request):
    return render(request, 'kca/07notice/sub_notice_05_01.html')


def SubNotice0601View(request):
#     notices = Notice.objects.all().order_by('-id')
    searchStr = request.POST.get('searchStr',"")
    
    notices = FAQ.objects.filter(content__contains=searchStr).order_by('-id')
    paginator = Paginator(notices, 10) 
    
    page = request.GET.get('page')
    try:
        pagenotices = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        pagenotices = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        pagenotices = paginator.page(paginator.num_pages)

    return render(request, 'kca/07notice/sub_notice_06_01.html', dict(notices=pagenotices, user=request.user))
def SubNotice0602View(request, pk):
    notices = FAQ.objects.filter(id = pk)
    return render(request, "kca/07notice/sub_notice_06_02.html", dict(notices=notices, user=request.user))

def SubNotice0701View(request):
    return render(request, 'kca/07notice/sub_notice_07_01.html')

def SubNotice0801View(request):
    return render(request, 'kca/07notice/sub_notice_08_01.html')


def SubNotice0901View(request):
#     notices = Notice.objects.all().order_by('-id')
    searchStr = request.POST.get('searchStr',"")
    
    notices = FAQ.objects.filter(content__contains=searchStr).order_by('-id')
    paginator = Paginator(notices, 10) 
    
    page = request.GET.get('page')
    try:
        pagenotices = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        pagenotices = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        pagenotices = paginator.page(paginator.num_pages)

    return render(request, 'kca/07notice/sub_notice_09_01.html', dict(notices=pagenotices, user=request.user))
def SubNotice0902View(request, pk):
    notices = FAQ.objects.filter(id = pk)
    return render(request, "kca/07notice/sub_notice_09_02.html", dict(notices=notices, user=request.user))



def sendmail():
    send_mail('Subject here', 'Here is the message.', 'hw.ralf79@gmail.com',
    ['hw.ralf79@gmail.com'], fail_silently=False)

def return_template(request):
    template = 'null'

    #if statements that choose what 'template' should be
    if request == 1:
        template = 'header.html'
    else:
        template = 'header.html'

    #render the template
    return render(request, template)

def vote(request, poll_id):
    p = get_object_or_404(Poll, pk=poll_id)
    try:
        selected_choice = p.choice_set.get(pk=request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        # Redisplay the poll voting form.
        return render(request, 'kca/detail.html', {
            'poll': p,
            'error_message': "You didn't select a choice.",
        })
    else:
        selected_choice.votes += 1
        selected_choice.save()
        # Always return an HttpResponseRedirect after successfully dealing
        # with POST data. This prevents data from being posted twice if a
        # user hits the Back button.
        return HttpResponseRedirect(reverse('kca:results', args=(p.id,)))
