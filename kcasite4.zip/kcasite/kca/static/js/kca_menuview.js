function menuView(id, show){
	
		if(id=="nav_01" && show == "show") {
			document.getElementById("nav_dropdown1").style.visibility = "visible";
			document.getElementById("nav_dropdown1").style.display = "block";
		} else {
			document.getElementById("nav_dropdown1").style.display = "none";
		}
	
		if(id=="nav_02" && show == "show") {
			document.getElementById("nav_dropdown2").style.visibility = "visible";
			document.getElementById("nav_dropdown2").style.display = "block";
		} else {
			document.getElementById("nav_dropdown2").style.display = "none";
		}
		
		if(id=="nav_03" && show == "show") {
			document.getElementById("nav_dropdown3").style.visibility = "visible";
			document.getElementById("nav_dropdown3").style.display = "block";
		} else {
			document.getElementById("nav_dropdown3").style.display = "none";
		}

		if(id=="nav_04" && show == "show") {
			document.getElementById("nav_dropdown4").style.visibility = "visible";
			document.getElementById("nav_dropdown4").style.display = "block";
		} else {
			document.getElementById("nav_dropdown4").style.display = "none";
		}
		
		if(id=="nav_05" && show == "show") {


			document.getElementById("nav_dropdown5").style.visibility = "visible";
			document.getElementById("nav_dropdown5").style.display = "block";
		} else {
			document.getElementById("nav_dropdown5").style.display = "none";
		}		
		
		if(id=="nav_06" && show == "show") {
			document.getElementById("nav_dropdown6").style.visibility = "visible";
			document.getElementById("nav_dropdown6").style.display = "block";
		} else {
			document.getElementById("nav_dropdown6").style.display = "none";
		}

		if(id=="nav_07" && show == "show") {
			document.getElementById("nav_dropdown7").style.visibility = "visible";
			document.getElementById("nav_dropdown7").style.display = "block";
		} else {
			document.getElementById("nav_dropdown7").style.display = "none";
		}
	}	